﻿namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var lizard = new Lizard("lizzy");
            var snake = new Snake("snakey");
            var gorilla = new Gorilla("kong");
            var bear = new Bear("teddy");
        }
    }
}