﻿using System;

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var typesToAssert = new[]
            {
            "BladeKnight",
            "DarkKnight",
            "DarkWizard",
            "Elf",
            "Hero",
            "Knight",
            "MuseElf",
            "SoulMaster",
            "Wizard"
             };
        }
    }
}