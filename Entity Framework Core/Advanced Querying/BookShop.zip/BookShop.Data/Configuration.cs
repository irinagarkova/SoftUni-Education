﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-78S3E9U\\MSSQL;Database=BookShop;Integrated Security=True;";
    }
}
