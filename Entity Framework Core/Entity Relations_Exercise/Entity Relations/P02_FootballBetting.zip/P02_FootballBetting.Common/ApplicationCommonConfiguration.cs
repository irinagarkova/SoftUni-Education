﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P02_FootballBetting.Common
{
    public static class ApplicationCommonConfiguration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-78S3E9U\MSSQL;Database=FootballBetting2025;Trusted_Connection=True;";
    }
}
